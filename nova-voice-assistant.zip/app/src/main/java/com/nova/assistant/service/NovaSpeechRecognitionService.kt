package com.nova.assistant.service

import android.content.Intent
import android.speech.RecognitionService

class NovaSpeechRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // Recognition logic
    }

    override fun onCancel(listener: Callback?) {
        // Cancel logic
    }

    override fun onStopListening(listener: Callback?) {
        // Stop logic
    }
}
