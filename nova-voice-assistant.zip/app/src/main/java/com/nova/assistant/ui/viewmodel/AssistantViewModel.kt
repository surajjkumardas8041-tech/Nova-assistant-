package com.nova.assistant.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.assistant.data.api.NovaAiBrainClient
import com.nova.assistant.data.model.AssistantIntentAction
import com.nova.assistant.data.model.CommandHistoryItem
import com.nova.assistant.data.model.NoteItem
import com.nova.assistant.data.model.ReminderItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AssistantUiState(
    val isListening: Boolean = false,
    val isLoading: Boolean = false,
    val isAssistantActive: Boolean = false,
    val recognizedSpeech: String = "",
    val assistantSpokenResponse: String = "",
    val language: String = "bn",
    val history: List<CommandHistoryItem> = emptyList(),
    val notes: List<NoteItem> = emptyList(),
    val reminders: List<ReminderItem> = emptyList(),
    val isFlashlightOn: Boolean = false
)

class AssistantViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    private var activeQueryJob: Job? = null

    fun setListening(listening: Boolean) {
        _uiState.update { it.copy(isListening = listening, isAssistantActive = listening || it.isAssistantActive) }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(language = if (it.language == "bn") "en" else "bn") }
    }

    fun dismissAssistant() {
        activeQueryJob?.cancel()
        _uiState.update { it.copy(isAssistantActive = false, isLoading = false, isListening = false) }
    }

    /**
     * Coroutine-based voice query processor.
     * Routes non-device general questions to the Nova AI brain asynchronously on Dispatchers.IO.
     * Automatically addresses Tapas Sir in Bengali.
     */
    fun processVoiceQuery(
        query: String,
        lang: String = "bn",
        onSpeak: ((String, String) -> Unit)? = null
    ) {
        activeQueryJob?.cancel()
        _uiState.update {
            it.copy(
                isListening = false,
                isLoading = true,
                isAssistantActive = true,
                recognizedSpeech = query
            )
        }

        activeQueryJob = viewModelScope.launch {
            val spokenReply = withContext(Dispatchers.IO) {
                val action = parseLocalIntent(query)
                if (action != null) {
                    getDeviceActionReply(action)
                } else {
                    NovaAiBrainClient.askAiBrain(query, lang)
                }
            }

            _uiState.update {
                it.copy(
                    isLoading = false,
                    assistantSpokenResponse = spokenReply
                )
            }

            onSpeak?.invoke(spokenReply, "bn")
        }
    }

    private fun parseLocalIntent(query: String): AssistantIntentAction? {
        val lower = query.lowercase().trim()
        return when {
            lower.contains("ইউটিউব") || lower.contains("youtube") -> AssistantIntentAction("OPEN_APP", mapOf("appName" to "youtube"))
            lower.contains("ফেসবুক") || lower.contains("facebook") -> AssistantIntentAction("OPEN_APP", mapOf("appName" to "facebook"))
            lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") -> AssistantIntentAction("OPEN_APP", mapOf("appName" to "whatsapp"))
            lower.contains("ফ্ল্যাশলাইট") || lower.contains("টর্চ") || lower.contains("flashlight") -> {
                val state = if (lower.contains("বন্ধ") || lower.contains("নিভিয়ে") || lower.contains("off")) "off" else "on"
                AssistantIntentAction("TOGGLE_FLASHLIGHT", mapOf("state" to state))
            }
            lower.contains("ম্যাপ") || lower.contains("maps") -> AssistantIntentAction("NAVIGATE_MAPS", mapOf("destination" to "Dhaka"))
            else -> null
        }
    }

    private fun getDeviceActionReply(action: AssistantIntentAction): String {
        return when (action.type) {
            "OPEN_APP" -> "হ্যাঁ তাপস স্যার, ${action.payload["appName"] ?: "অ্যাপ্লিকেশন"} খোলা হচ্ছে।"
            "TOGGLE_FLASHLIGHT" -> if (action.payload["state"] == "off") "ফ্ল্যাশলাইট বন্ধ করা হয়েছে।" else "ফ্ল্যাশলাইট জ্বালানো হয়েছে।"
            "NAVIGATE_MAPS" -> "ম্যাপস নেভিগেশন শুরু করা হয়েছে।"
            else -> "নির্দেশ সম্পন্ন করা হয়েছে।"
        }
    }
}
