package com.nova.assistant.intents

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nova.assistant.data.model.AssistantIntentAction

class IntentActionHandler(private val context: Context) {
    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }
    private var isTorchOn = false

    /**
     * Executes the requested intent action and returns an execution result status with message.
     */
    fun executeIntent(action: AssistantIntentAction): Pair<Boolean, String> {
        return when (action.type) {
            "OPEN_APP" -> {
                val appName = action.payload["appName"] ?: ""
                val launched = openApp(appName)
                if (launched) {
                    Pair(true, "অ্যাপ্লিকেশন খোলা হয়েছে, ${getDisplayName(appName)}")
                } else {
                    Pair(false, "অ্যাপ্লিকেশন খুঁজে পাওয়া যায়নি, ${getDisplayName(appName)}")
                }
            }
            "CALL_PHONE" -> {
                val phone = action.payload["phoneNumber"] ?: ""
                makeSafeCall(phone)
                Pair(true, "ফোন ডায়াল করা হচ্ছে")
            }
            "ACCEPT_CALL" -> {
                acceptIncomingCall()
            }
            "END_CALL" -> {
                endOrRejectCall()
            }
            "SEND_SMS" -> {
                val recipient = action.payload["recipient"] ?: ""
                val message = action.payload["message"] ?: ""
                composeSms(recipient, message)
                Pair(true, "এসএমএস তৈরি করা হয়েছে")
            }
            "NAVIGATE_MAPS" -> {
                val destination = action.payload["destination"] ?: "Dhaka"
                val success = startNavigation(destination)
                if (success) {
                    Pair(true, "ম্যাপস নেভিগেশন শুরু হয়েছে, ${destination}-এর দিকে")
                } else {
                    Pair(false, "গন্তব্য খুঁজে পাওয়া যায়নি")
                }
            }
            "TOGGLE_FLASHLIGHT" -> {
                val state = action.payload["state"]
                val (success, msg) = toggleFlashlight(state)
                Pair(success, msg)
            }
            "SEARCH_WEB" -> {
                val query = action.payload["query"] ?: ""
                searchWeb(query)
                Pair(true, "গুগলে সার্চ করা হচ্ছে")
            }
            else -> Pair(true, "কমান্ড সম্পন্ন হয়েছে")
        }
    }

    private fun getDisplayName(appName: String): String {
        return when (appName.lowercase()) {
            "youtube" -> "YouTube"
            "facebook" -> "Facebook"
            "whatsapp" -> "WhatsApp"
            "maps" -> "Google Maps"
            "chrome" -> "Chrome"
            "gmail" -> "Gmail"
            "camera" -> "ক্যামেরা"
            "settings" -> "সেটিংস"
            "calculator" -> "ক্যালকুলেটর"
            else -> appName
        }
    }

    /**
     * 1. Safe App Opener
     */
    fun openApp(appName: String): Boolean {
        val packageMap = mapOf(
            "youtube" to "com.google.android.youtube",
            "facebook" to "com.facebook.katana",
            "whatsapp" to "com.whatsapp",
            "maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm",
            "chrome" to "com.android.chrome",
            "calculator" to "com.google.android.calculator",
            "camera" to "android.media.action.IMAGE_CAPTURE",
            "settings" to "android.settings.SETTINGS"
        )
        val target = appName.lowercase().trim()
        val pkg = packageMap[target] ?: target

        try {
            if (target == "camera") {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }
            if (target == "settings") {
                val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }

            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }

            if (target == "youtube") {
                val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (ytIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(ytIntent)
                    return true
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "অ্যাপ চালু করতে সমস্যা হয়েছে: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            return false
        }
        Toast.makeText(context, "$appName ইনস্টল করা নেই", Toast.LENGTH_SHORT).show()
        return false
    }

    /**
     * 2. Safe Phone Calling
     */
    fun makeSafeCall(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${Uri.encode(phoneNumber)}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 3. Safe SMS Composer
     */
    fun composeSms(recipient: String, message: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(recipient)}")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 4. Google Maps Navigation Intent
     */
    fun startNavigation(destination: String): Boolean {
        val gmmIntentUri = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
            true
        } else {
            val webUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(destination)}")
            val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            true
        }
    }

    /**
     * 5. Device Flashlight Torch Controller
     */
    fun toggleFlashlight(state: String?): Pair<Boolean, String> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (context is Activity) {
                ActivityCompat.requestPermissions(context, arrayOf(Manifest.permission.CAMERA), 1002)
            }
            val deniedMsg = "ক্যামেরা পারমিশন প্রয়োজন ফ্ল্যাশলাইটের জন্য"
            Toast.makeText(context, deniedMsg, Toast.LENGTH_SHORT).show()
            return Pair(false, deniedMsg)
        }

        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            Toast.makeText(context, "ডিভাইসে ফ্ল্যাশলাইট হার্ডওয়্যার নেই", Toast.LENGTH_SHORT).show()
            return Pair(false, "ডিভাইসে ফ্ল্যাশলাইট নেই")
        }

        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val isBackFacing = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                hasFlash && isBackFacing
            }

            if (cameraId == null) {
                return Pair(false, "ক্যামেরা ফ্ল্যাশলাইট পাওয়া যায়নি")
            }

            val shouldTurnOn = when (state?.lowercase()) {
                "on" -> true
                "off" -> false
                else -> !isTorchOn
            }

            cameraManager.setTorchMode(cameraId, shouldTurnOn)
            isTorchOn = shouldTurnOn
            val spokenReply = if (shouldTurnOn) {
                "ফ্ল্যাশলাইট জ্বালানো হয়েছে"
            } else {
                "ফ্ল্যাশলাইট বন্ধ করা হয়েছে"
            }
            val toastMsg = if (shouldTurnOn) "ফ্ল্যাশলাইট অন" else "ফ্ল্যাশলাইট অফ"
            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
            Pair(true, spokenReply)
        } catch (e: CameraAccessException) {
            val err = "ক্যামেরা এক্সেস সমস্যা: ${e.localizedMessage}"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            Pair(false, err)
        } catch (e: SecurityException) {
            val err = "ক্যামেরা পারমিশন ত্রুটি"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            Pair(false, err)
        } catch (e: Exception) {
            val err = "ফ্ল্যাশলাইট ত্রুটি: ${e.localizedMessage}"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            Pair(false, err)
        }
    }

    /**
     * 6. Web Search Intent
     */
    fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 7. Accept Incoming Ringing Phone Call
     */
    fun acceptIncomingCall(): Pair<Boolean, String> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            val errMsg = "কল রিসিভ করার পারমিশন নেই"
            Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
            return Pair(false, errMsg)
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                if (telecomManager != null) {
                    telecomManager.acceptRingingCall()
                    val msg = "কল রিসিভ করা হয়েছে"
                    Toast.makeText(context, "কল রিসিভ করা হয়েছে", Toast.LENGTH_SHORT).show()
                    Pair(true, msg)
                } else {
                    Pair(false, "টেলিকম সার্ভিস পাওয়া যায়নি")
                }
            } else {
                Pair(false, "ভার্সন সাপোর্ট নেই")
            }
        } catch (e: SecurityException) {
            val msg = "পারমিশন সমস্যা"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        } catch (e: Exception) {
            val msg = "কল রিসিভ ত্রুটি: ${e.localizedMessage}"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        }
    }

    /**
     * 8. End or Reject Incoming / Active Phone Call
     */
    fun endOrRejectCall(): Pair<Boolean, String> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            val errMsg = "কল কাটার পারমিশন নেই"
            Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
            return Pair(false, errMsg)
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                val ended = telecomManager?.endCall() ?: false
                if (ended) {
                    val msg = "কল কেটে দেওয়া হয়েছে"
                    Toast.makeText(context, "কল কেটে দেওয়া হয়েছে", Toast.LENGTH_SHORT).show()
                    Pair(true, msg)
                } else {
                    Pair(false, "কল কাটা যায়নি")
                }
            } else {
                Pair(false, "ভার্সন সাপোর্ট নেই")
            }
        } catch (e: SecurityException) {
            val msg = "পারমিশন সমস্যা"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        } catch (e: Exception) {
            val msg = "কল কাটা ত্রুটি: ${e.localizedMessage}"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        }
    }
}
