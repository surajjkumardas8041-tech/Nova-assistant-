package com.nova.assistant.data.local

import android.content.Context
import android.content.SharedPreferences

/**
 * PreferencesManager
 * Persistent Key-Value store for Assistant settings.
 */
class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "nova_assistant_preferences"
        private const val KEY_WAKE_WORD_ENABLED = "key_wake_word_enabled"
        private const val KEY_ASSISTANT_LANGUAGE = "key_assistant_language"
        private const val KEY_VOICE_GENDER = "key_voice_gender"
        private const val KEY_SPEECH_RATE = "key_speech_rate"
        private const val KEY_SPEECH_PITCH = "key_speech_pitch"

        @Volatile
        private var instance: PreferencesManager? = null

        fun getInstance(context: Context): PreferencesManager {
            return instance ?: synchronized(this) {
                instance ?: PreferencesManager(context.applicationContext).also { instance = it }
            }
        }

        fun isWakeWordEnabled(context: Context): Boolean {
            return getInstance(context).isWakeWordEnabled()
        }

        fun setWakeWordEnabled(context: Context, enabled: Boolean) {
            getInstance(context).setWakeWordEnabled(enabled)
        }
    }

    fun isWakeWordEnabled(): Boolean {
        return prefs.getBoolean(KEY_WAKE_WORD_ENABLED, true)
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, enabled).apply()
    }

    fun getLanguage(): String {
        return prefs.getString(KEY_ASSISTANT_LANGUAGE, "bn") ?: "bn"
    }

    fun setLanguage(language: String) {
        prefs.edit().putString(KEY_ASSISTANT_LANGUAGE, language).apply()
    }

    fun getVoiceGender(): String {
        return prefs.getString(KEY_VOICE_GENDER, "male") ?: "male"
    }

    fun setVoiceGender(gender: String) {
        prefs.edit().putString(KEY_VOICE_GENDER, gender).apply()
    }

    fun getSpeechRate(): Float {
        return prefs.getFloat(KEY_SPEECH_RATE, 1.02f)
    }

    fun setSpeechRate(rate: Float) {
        prefs.edit().putFloat(KEY_SPEECH_RATE, rate).apply()
    }

    fun getSpeechPitch(): Float {
        return prefs.getFloat(KEY_SPEECH_PITCH, 0.98f)
    }

    fun setSpeechPitch(pitch: Float) {
        prefs.edit().putFloat(KEY_SPEECH_PITCH, pitch).apply()
    }
}
