package com.nova.assistant.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.speech.SpeechRecognizerManager
import com.nova.assistant.speech.TextToSpeechManager
import com.nova.assistant.ui.theme.NovaAssistantTheme

class AssistantOverlayActivity : ComponentActivity() {
    private lateinit var speechManager: SpeechRecognizerManager
    private lateinit var ttsManager: TextToSpeechManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speechManager = SpeechRecognizerManager(this)
        ttsManager = TextToSpeechManager(this)

        setContent {
            NovaAssistantTheme {
                var promptText by remember { mutableStateOf("শুনছি... কথা বলুন") }

                LaunchedEffect(Unit) {
                    speechManager.startListening(
                        language = "bn",
                        onResult = { result ->
                            promptText = result
                            ttsManager.speak(result, "bn") {
                                finish()
                            }
                        },
                        onError = {
                            finish()
                        }
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f))
                        .clickable { finish() },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = promptText,
                                fontSize = 18.sp,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
        ttsManager.shutdown()
    }
}
