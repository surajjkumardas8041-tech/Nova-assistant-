package com.nova.assistant.data.model

data class AssistantIntentAction(
    val type: String,
    val payload: Map<String, String> = emptyMap()
)

data class CommandHistoryItem(
    val id: Long = 0,
    val query: String,
    val response: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class NoteItem(
    val id: Long = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ReminderItem(
    val id: Long = 0,
    val title: String,
    val time: String,
    val isCompleted: Boolean = false
)
