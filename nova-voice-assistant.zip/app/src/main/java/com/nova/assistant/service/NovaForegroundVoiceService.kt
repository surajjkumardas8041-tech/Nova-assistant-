package com.nova.assistant.service

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.R
import com.nova.assistant.data.local.PreferencesManager
import com.nova.assistant.data.model.AssistantIntentAction
import com.nova.assistant.intents.IntentActionHandler
import com.nova.assistant.speech.SpeechRecognizerManager
import com.nova.assistant.speech.TextToSpeechManager
import com.nova.assistant.util.BatteryOptimizationHelper
import kotlinx.coroutines.*

/**
 * NovaForegroundVoiceService
 * Android 14+ (API 34+) compliant Foreground Microphone Voice Assistant Service.
 */
class NovaForegroundVoiceService : Service() {
    companion object {
        const val TAG = "NovaForegroundService"
        const val ACTION_START_STANDBY = "com.nova.assistant.ACTION_START_STANDBY"
        const val ACTION_STOP_SERVICE = "com.nova.assistant.ACTION_STOP_SERVICE"
        const val ACTION_INCOMING_CALL = "com.nova.assistant.ACTION_INCOMING_CALL"
        const val EXTRA_INCOMING_NUMBER = "extra_incoming_number"

        // Real-Time Diagnostic Broadcast
        const val ACTION_WAKE_WORD_STATUS = "com.nova.assistant.ACTION_WAKE_WORD_STATUS"
        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_TIMESTAMP = "extra_timestamp"

        const val STATUS_STANDBY_LISTENING = "STANDBY_LISTENING"
        const val STATUS_WAKE_WORD_DETECTED = "WAKE_WORD_DETECTED"
        const val STATUS_LISTENING_COMMAND = "LISTENING_COMMAND"
        const val STATUS_PROCESSING = "PROCESSING"
        const val STATUS_SPEAKING = "SPEAKING"
        const val STATUS_STOPPED = "STOPPED"
        const val STATUS_PERMISSION_REQUIRED = "PERMISSION_REQUIRED"
        const val STATUS_BATTERY_RESTRICTED = "BATTERY_RESTRICTED"

        const val CHANNEL_ID = "nova_voice_assistant_channel"
        const val NOTIFICATION_ID = 2024

        @Volatile
        var isServiceActive: Boolean = false
            private set

        @Volatile
        var currentDiagnosticStatus: String = STATUS_STOPPED
            private set
    }

    private var speechRecognizerManager: SpeechRecognizerManager? = null
    private var textToSpeechManager: TextToSpeechManager? = null
    private var intentActionHandler: IntentActionHandler? = null
    private var isStandby = false
    private var isExecutingCommand = false

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var currentCommandJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Nova Foreground Voice Service Created")
        createNotificationChannel()
        speechRecognizerManager = SpeechRecognizerManager(this)
        textToSpeechManager = TextToSpeechManager(this)
        intentActionHandler = IntentActionHandler(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_STANDBY
        when (action) {
            ACTION_STOP_SERVICE -> {
                stopStandby()
                broadcastDiagnosticStatus(STATUS_STOPPED, "সার্ভিস বন্ধ রয়েছে")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_STANDBY -> {
                val isEnabled = PreferencesManager.isWakeWordEnabled(this)
                if (!isEnabled) {
                    Log.i(TAG, "Wake word is disabled in settings; stopping standby service.")
                    stopStandby()
                    broadcastDiagnosticStatus(STATUS_STOPPED, "ওয়েকওয়ার্ড বন্ধ রয়েছে")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }
                val hasMicPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasMicPermission) {
                    Log.e(TAG, "Cannot start Wake Word: RECORD_AUDIO permission missing!")
                    isServiceActive = false
                    broadcastDiagnosticStatus(
                        STATUS_PERMISSION_REQUIRED,
                        "মাইক্রোফোন পারমিশন প্রয়োজন"
                    )
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundServiceWithNotification()
                startStandbyWakeWordListening()
            }
            ACTION_INCOMING_CALL -> {
                val number = intent?.getStringExtra(EXTRA_INCOMING_NUMBER) ?: ""
                handleIncomingCallEvent(number)
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Nova Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Nova Assistant Voice Service"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceWithNotification() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val isBatteryProtected = BatteryOptimizationHelper.isIgnoringBatteryOptimizations(this)
        val statusSubtitle = if (isBatteryProtected) {
            "স্ট্যান্ডবাই মোডে সক্রিয় ('Nova' বলুন)"
        } else {
            "স্ট্যান্ডবাই মোডে সক্রিয়"
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ভয়েস অ্যাসিস্ট্যান্ট (Nova)")
            .setContentText(statusSubtitle)
            .setSmallIcon(R.drawable.ic_nova_tile)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startStandbyWakeWordListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Cannot start standby: RECORD_AUDIO permission missing")
            broadcastDiagnosticStatus(STATUS_PERMISSION_REQUIRED, "মাইক্রোফোন পারমিশন প্রয়োজন")
            isServiceActive = false
            return
        }

        isStandby = true
        isServiceActive = true
        broadcastDiagnosticStatus(STATUS_STANDBY_LISTENING, "স্ট্যান্ডবাই সক্রিয়: 'Nova' বলুন")
        Log.i(TAG, "Nova is now in low-power Standby state listening for Wake Word 'Nova'...")

        speechRecognizerManager?.startListening(
            language = "bn",
            onResult = { transcript ->
                handleIncomingSpokenUtterance(transcript)
            },
            onError = { _ ->
                if (isStandby && !isExecutingCommand) {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (isStandby && !isExecutingCommand) {
                            startStandbyWakeWordListening()
                        }
                    }, 400)
                }
            }
        )
    }

    private fun handleIncomingSpokenUtterance(rawText: String) {
        val text = rawText.trim()
        val lower = text.lowercase()

        val hasWakeWord = lower.contains("নোভা") || lower.contains("nova") || lower.contains("hey nova")
        if (hasWakeWord || isStandby) {
            val cleanedQuery = text
                .replace("(?i)hey nova".toRegex(), "")
                .replace("(?i)hello nova".toRegex(), "")
                .replace("(?i)nova".toRegex(), "")
                .replace("নোভা", "")
                .trim()

            if (cleanedQuery.isBlank()) {
                isExecutingCommand = true
                broadcastDiagnosticStatus(STATUS_WAKE_WORD_DETECTED, "ওয়েকওয়ার্ড শনাক্ত হয়েছে...")
                val promptMsg = "হ্যাঁ তাপস স্যার, বলুন আমি শুনছি..."
                textToSpeechManager?.speak(promptMsg, "bn")
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    listenForFinalCommand()
                }, 1400)
            } else {
                broadcastDiagnosticStatus(STATUS_WAKE_WORD_DETECTED, "কমান্ড শনাক্ত হয়েছে")
                executeCommand(cleanedQuery)
            }
        }
    }

    private fun listenForFinalCommand() {
        isExecutingCommand = true
        broadcastDiagnosticStatus(STATUS_LISTENING_COMMAND, "কমান্ড শোনা হচ্ছে...")
        speechRecognizerManager?.startListening(
            language = "bn",
            onResult = { commandText ->
                executeCommand(commandText)
            },
            onError = { error ->
                isExecutingCommand = false
                val errMsg = "দুঃখিত তাপস স্যার, $error"
                textToSpeechManager?.speak(errMsg, "bn")
                startStandbyWakeWordListening()
            }
        )
    }

    private fun handleIncomingCallEvent(incomingNumber: String) {
        isExecutingCommand = true
        speechRecognizerManager?.stopListening()
        val announcement = "তাপস স্যার, ইনকামিং কল আসছে। আপনি কি কলটি রিসিভ করবেন নাকি কেটে দেবেন?"
        Log.i(TAG, "Announcing incoming call to Tapas Sir: $announcement")
        textToSpeechManager?.speak(announcement, "bn")

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            broadcastDiagnosticStatus(STATUS_LISTENING_COMMAND, "কল কমান্ড শোনা হচ্ছে...")
            speechRecognizerManager?.startListening(
                language = "bn",
                onResult = { voiceCommand ->
                    executeCommand(voiceCommand)
                },
                onError = { _ ->
                    isExecutingCommand = false
                    if (isStandby) {
                        startStandbyWakeWordListening()
                    }
                }
            )
        }, 1800)
    }

    private fun executeCommand(command: String) {
        currentCommandJob?.cancel()
        isExecutingCommand = true
        broadcastDiagnosticStatus(STATUS_PROCESSING, "প্রসেসিং: '$command'")
        Log.i(TAG, "Executing command for Tapas Sir: $command")

        val action = parseIntentAction(command)
        if (action != null) {
            val (_, outcomeMsg) = intentActionHandler?.executeIntent(action) ?: Pair(false, "কাজটি করা সম্ভব হয়নি")
            speakAndFinishCommand(outcomeMsg)
        } else {
            currentCommandJob = serviceScope.launch {
                val aiResponse = withContext(Dispatchers.IO) {
                    com.nova.assistant.data.api.NovaAiBrainClient.askAiBrain(command, "bn")
                }
                speakAndFinishCommand(aiResponse)
            }
        }
    }

    private fun speakAndFinishCommand(responseText: String) {
        broadcastDiagnosticStatus(STATUS_SPEAKING, "উত্তর দেওয়া হচ্ছে...")
        textToSpeechManager?.speak(responseText, "bn")
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            isExecutingCommand = false
            if (isStandby) {
                startStandbyWakeWordListening()
            }
        }, 2800)
    }

    private fun parseIntentAction(query: String): AssistantIntentAction? {
        val lower = query.lowercase().trim()
        return when {
            lower.contains("ধরো") || lower.contains("রিসিভ") || lower.contains("receive") || lower.contains("accept") || lower.contains("তুলো") -> {
                AssistantIntentAction("ACCEPT_CALL", emptyMap())
            }
            lower.contains("কেটে দাও") || lower.contains("কাটো") || lower.contains("কেটে") || lower.contains("reject") || lower.contains("end call") || lower.contains("বাতিল") -> {
                AssistantIntentAction("END_CALL", emptyMap())
            }
            lower.contains("ইউটিউব") || lower.contains("youtube") || lower.contains("yt") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "youtube"))
            }
            lower.contains("ফেসবুক") || lower.contains("facebook") || lower.contains("fb") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "facebook"))
            }
            lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "whatsapp"))
            }
            lower.contains("ক্রোম") || lower.contains("chrome") || lower.contains("ব্রাউজার") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "chrome"))
            }
            lower.contains("ক্যামেরা") || lower.contains("camera") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "camera"))
            }
            lower.contains("সেটিংস") || lower.contains("settings") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "settings"))
            }
            lower.contains("ফ্ল্যাশলাইট") || lower.contains("টর্চ") || lower.contains("flashlight") || lower.contains("torch") -> {
                val isTurnOff = lower.contains("বন্ধ") || lower.contains("নিভিয়ে") || lower.contains("নিভাও") || lower.contains("off")
                val state = if (isTurnOff) "off" else "on"
                AssistantIntentAction("TOGGLE_FLASHLIGHT", mapOf("state" to state))
            }
            lower.contains("ম্যাপস") || lower.contains("ম্যাপ") || lower.contains("maps") || lower.contains("রাস্তা") -> {
                val destination = query.replace("ম্যাপস", "").replace("maps", "").replace("রাস্তা", "").replace("খোলো", "").trim()
                val target = if (destination.isEmpty()) "Dhaka" else destination
                AssistantIntentAction("NAVIGATE_MAPS", mapOf("destination" to target))
            }
            lower.contains("কল করো") || lower.contains("ফোন করো") || lower.contains("call") -> {
                AssistantIntentAction("CALL_PHONE", mapOf("phoneNumber" to ""))
            }
            else -> null
        }
    }

    private fun broadcastDiagnosticStatus(status: String, message: String) {
        currentDiagnosticStatus = status
        val intent = Intent(ACTION_WAKE_WORD_STATUS).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_TIMESTAMP, System.currentTimeMillis())
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun stopStandby() {
        isStandby = false
        isServiceActive = false
        speechRecognizerManager?.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        stopStandby()
        broadcastDiagnosticStatus(STATUS_STOPPED, "সার্ভিস বন্ধ রয়েছে")
        speechRecognizerManager?.destroy()
        textToSpeechManager?.shutdown()
        Log.i(TAG, "Nova Foreground Voice Service Destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
