package com.nova.assistant.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.nova.assistant.service.NovaForegroundVoiceService

/**
 * IncomingCallReceiver
 * BroadcastReceiver listening for incoming phone calls via android.intent.action.PHONE_STATE.
 */
class IncomingCallReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "IncomingCallReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
            Log.i(TAG, "Phone state changed: $stateStr, Incoming: $incomingNumber")

            if (stateStr == TelephonyManager.EXTRA_STATE_RINGING) {
                Log.i(TAG, "Incoming call ringing! Triggering voice announcement for Tapas Sir...")
                val serviceIntent = Intent(context, NovaForegroundVoiceService::class.java).apply {
                    action = NovaForegroundVoiceService.ACTION_INCOMING_CALL
                    putExtra(NovaForegroundVoiceService.EXTRA_INCOMING_NUMBER, incomingNumber)
                }
                try {
                    ContextCompat.startForegroundService(context, serviceIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to start Nova service on incoming call: ${e.localizedMessage}")
                }
            }
        }
    }
}
