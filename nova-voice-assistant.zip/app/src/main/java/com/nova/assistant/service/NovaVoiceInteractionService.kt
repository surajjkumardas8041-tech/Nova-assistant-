package com.nova.assistant.service

import android.content.ComponentName
import android.content.Context
import android.service.voice.VoiceInteractionService
import android.util.Log

/**
 * Nova Voice Interaction Service
 * Provides Android System Assistant integration (e.g. Long-press home, power button assistant trigger).
 */
class NovaVoiceInteractionService : VoiceInteractionService() {
    companion object {
        private const val TAG = "NovaVoiceService"

        fun isActive(context: Context): Boolean {
            val component = ComponentName(context, NovaVoiceInteractionService::class.java)
            return VoiceInteractionService.isActiveService(context, component)
        }
    }

    override fun onReady() {
        super.onReady()
        Log.i(TAG, "Nova Voice Interaction Service is READY as Android Default Digital Assistant")
    }

    override fun onShutdown() {
        super.onShutdown()
        Log.i(TAG, "Nova Voice Interaction Service shutdown")
    }
}
