package com.nova.assistant.speech

import android.content.Context
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

class TextToSpeechManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isInitialized = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupNaturalMaleVoice("bn")
            Log.i("NovaTTS", "TTS Initialized successfully with Bengali Male Voice preference")
        } else {
            Log.e("NovaTTS", "TTS Initialization failed with status: $status")
        }
    }

    private fun setupNaturalMaleVoice(language: String) {
        val ttsInstance = tts ?: return
        try {
            var currentLocale = if (language == "bn") Locale("bn", "IN") else Locale.US
            var langResult = ttsInstance.setLanguage(currentLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                if (language == "bn") {
                    Log.w("NovaTTS", "bn-IN missing or not supported, falling back to bn-BD")
                    currentLocale = Locale("bn", "BD")
                    langResult = ttsInstance.setLanguage(currentLocale)
                    if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.w("NovaTTS", "bn-BD missing, falling back to English")
                        ttsInstance.setLanguage(Locale.US)
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val availableVoices = ttsInstance.voices
                if (!availableVoices.isNullOrEmpty()) {
                    val isMale = { voice: Voice ->
                        val name = voice.name.lowercase()
                        val maleKeys = listOf("male", "man", "pradeep", "arjun", "anand", "deep", "kumar", "sourav", "subir", "rahul", "amit", "david", "-b", "-c")
                        val femaleKeys = listOf("female", "woman", "girl", "zira", "swara", "sangeeta", "geeta", "shona", "tanisha", "mithu", "-a", "-d")
                        val hasMaleKey = maleKeys.any { name.contains(it) }
                        val hasFemaleKey = femaleKeys.any { name.contains(it) }
                        hasMaleKey || (!hasFemaleKey && (voice.features?.contains("male") == true || name.contains("male")))
                    }
                    val isFemale = { voice: Voice ->
                        val name = voice.name.lowercase()
                        val femaleKeys = listOf("female", "woman", "girl", "zira", "swara", "sangeeta", "geeta", "shona", "tanisha", "mithu", "-a", "-d")
                        femaleKeys.any { name.contains(it) }
                    }

                    if (language == "bn") {
                        val bnVoices = availableVoices.filter {
                            it.locale.language.equals("bn", ignoreCase = true) ||
                            it.name.lowercase().contains("bengali") ||
                            it.name.lowercase().contains("bangla")
                        }
                        val bnInVoices = bnVoices.filter {
                            it.locale.country.equals("IN", ignoreCase = true) || it.name.lowercase().contains("in") || it.name.lowercase().contains("india")
                        }
                        val bnBdVoices = bnVoices.filter {
                            it.locale.country.equals("BD", ignoreCase = true) || it.name.lowercase().contains("bd") || it.name.lowercase().contains("bangladesh")
                        }
                        val bestVoice = bnInVoices.find { isMale(it) && (it.name.lowercase().contains("natural") || it.name.lowercase().contains("neural") || it.name.lowercase().contains("wavenet")) }
                            ?: bnInVoices.find { isMale(it) }
                            ?: bnInVoices.find { !isFemale(it) }
                            ?: bnInVoices.firstOrNull()
                            ?: bnBdVoices.find { isMale(it) && (it.name.lowercase().contains("natural") || it.name.lowercase().contains("neural") || it.name.lowercase().contains("wavenet")) }
                            ?: bnBdVoices.find { isMale(it) }
                            ?: bnBdVoices.find { !isFemale(it) }
                            ?: bnVoices.firstOrNull()
                        bestVoice?.let {
                            ttsInstance.voice = it
                            Log.i("NovaTTS", "Configured Natural Bengali Male Voice: ${it.name} (${it.locale})")
                        }
                    } else {
                        val enVoices = availableVoices.filter { it.locale.language.equals("en", ignoreCase = true) }
                        val bestEnVoice = enVoices.find { isMale(it) && (it.name.lowercase().contains("natural") || it.name.lowercase().contains("neural") || it.name.lowercase().contains("google")) }
                            ?: enVoices.find { isMale(it) }
                            ?: enVoices.firstOrNull()
                        bestEnVoice?.let {
                            ttsInstance.voice = it
                            Log.i("NovaTTS", "Configured English Male Voice: ${it.name}")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("NovaTTS", "Voice configuration fallback: ${e.localizedMessage}")
        }
    }

    fun speak(text: String, language: String = "bn", onDone: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            onDone?.invoke()
            return
        }

        stop()
        val hasBengaliChars = Regex("[\\u0980-\\u09FF]").containsMatchIn(text)
        val targetLang = if (hasBengaliChars) "bn" else language
        setupNaturalMaleVoice(targetLang)

        tts?.setSpeechRate(1.02f)
        tts?.setPitch(0.98f)
        val utteranceId = "NOVA_UTTERANCE_${System.currentTimeMillis()}"
        if (onDone != null) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(id: String?) {
                    if (id == utteranceId) onDone()
                }
                override fun onError(utteranceId: String?) {
                    onDone()
                }
            })
        }

        val cleanSpeech = text
            .replace(Regex("[*#_~]"), "")
            .replace(Regex("https?://\\S+"), "")
            .trim()
        tts?.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
