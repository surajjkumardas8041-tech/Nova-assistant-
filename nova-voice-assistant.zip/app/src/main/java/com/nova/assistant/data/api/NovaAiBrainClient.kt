package com.nova.assistant.data.api

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * NovaAiBrainClient
 * Asynchronously queries the server-side AI model for general voice questions
 * using Kotlin Coroutines on Dispatchers.IO.
 */
object NovaAiBrainClient {
    private const val TAG = "NovaAiBrainClient"
    private const val TIMEOUT_MS = 6500L
    private const val BACKEND_ENDPOINT = "https://nova-assistant-api.app/api/assistant/process"

    suspend fun askAiBrain(query: String, language: String = "bn"): String {
        return withContext(Dispatchers.IO) {
            val result = withTimeoutOrNull(TIMEOUT_MS) {
                try {
                    val url = URL(BACKEND_ENDPOINT)
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 5000
                        readTimeout = 5000
                        doOutput = true
                        doInput = true
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        setRequestProperty("Accept", "application/json")
                    }
                    val jsonPayload = JSONObject().apply {
                        put("query", query)
                        put("language", language)
                    }
                    val writer = OutputStreamWriter(connection.outputStream, "UTF-8")
                    writer.write(jsonPayload.toString())
                    writer.flush()
                    writer.close()

                    val responseCode = connection.responseCode
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        val reader = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8"))
                        val sb = StringBuilder()
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            sb.append(line)
                        }
                        reader.close()
                        val jsonResponse = JSONObject(sb.toString())
                        val spokenReply = jsonResponse.optString("spokenResponse", "")
                        val textReply = jsonResponse.optString("textResponse", "")

                        if (spokenReply.isNotBlank()) spokenReply else textReply
                    } else {
                        Log.w(TAG, "Server error code: $responseCode")
                        getLocalSmartFallback(query)
                    }
                } catch (e: SocketTimeoutException) {
                    Log.w(TAG, "AI Brain request timed out: ${e.message}")
                    "দুঃখিত তাপস স্যার, সার্ভার রেসপন্স করতে দেরি হচ্ছে।"
                } catch (e: UnknownHostException) {
                    Log.w(TAG, "Network unavailable / offline: ${e.message}")
                    getLocalSmartFallback(query)
                } catch (e: Exception) {
                    Log.e(TAG, "AI Brain query error: ${e.localizedMessage}")
                    getLocalSmartFallback(query)
                }
            }
            result ?: "আমি আপনার কথাটি বুঝতে পেরেছি কিন্তু এই মুহূর্তে নেটওয়ার্ক সংযোগ পাওয়া যাচ্ছে না।"
        }
    }

    /**
     * Local offline fallback intelligence when network is unavailable
     */
    private fun getLocalSmartFallback(query: String): String {
        val lower = query.lowercase().trim()
        return when {
            lower.contains("কেমন আছো") || lower.contains("how are you") || lower.contains("kemon acho") ->
                "আমি ভালো আছি তাপস স্যার, আপনি কেমন আছেন?"
            lower.contains("তোমার নাম") || lower.contains("your name") || lower.contains("কে তুমি") ->
                "আমার নাম নোভা, আপনার পার্সোনাল ভয়েস অ্যাসিস্ট্যান্ট।"
            lower.contains("আবহাওয়া") || lower.contains("weather") || lower.contains("abohawa") ->
                "আজকের আবহাওয়া বেশ ভালো ও রৌদ্রোজ্জ্বল।"
            lower.contains("ধন্যবাদ") || lower.contains("thank you") || lower.contains("thanks") ->
                "আপনাকে অনেক ধন্যবাদ তাপস স্যার! সর্বদা আপনার সেবায় নিয়োজিত।"
            lower.contains("সময়") || lower.contains("time") ->
                "বর্তমান সময় এবং তারিখ দেখতে আপনার স্ক্রিন চেক করুন।"
            else ->
                "আমি আপনার নির্দেশ বুঝতে পেরেছি এবং সেই অনুযায়ী সহায়তা করছি তাপস স্যার।"
        }
    }
}
