package com.nova.assistant.receiver

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.nova.assistant.data.local.PreferencesManager
import com.nova.assistant.service.NovaForegroundVoiceService

/**
 * BootCompletedReceiver
 * Automatically restores and boots the Nova Foreground Voice Assistant Standby Service on boot.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "NovaBootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.i(TAG, "Device booted / power on received with action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val isWakeWordEnabled = PreferencesManager.isWakeWordEnabled(context)
            if (!isWakeWordEnabled) {
                Log.i(TAG, "Wake word is disabled in settings; skipping auto-start on boot.")
                return
            }

            val hasMicPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (hasMicPermission) {
                Log.i(TAG, "Starting Nova Always-Ready Standby Voice Service on Boot...")
                val serviceIntent = Intent(context, NovaForegroundVoiceService::class.java).apply {
                    this.action = NovaForegroundVoiceService.ACTION_START_STANDBY
                }
                try {
                    ContextCompat.startForegroundService(context, serviceIntent)
                    Log.i(TAG, "Nova Foreground Voice Service successfully launched in Standby Mode on Boot.")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to start Nova Foreground Service on Boot: ${e.localizedMessage}")
                }
            } else {
                Log.w(TAG, "Microphone permission not granted; standby service startup deferred.")
            }
        }
    }
}
