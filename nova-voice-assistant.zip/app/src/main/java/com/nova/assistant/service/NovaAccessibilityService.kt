package com.nova.assistant.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Nova Accessibility Service
 * Strictly respects Android security.
 */
class NovaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Safe UI automation when permitted by user
    }

    override fun onInterrupt() {
    }
}
